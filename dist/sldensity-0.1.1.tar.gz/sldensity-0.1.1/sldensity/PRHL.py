def dPRHL(x, a, m, l):
    s= a*l*np.exp(-l*(x-m))/(1+np.exp(-l*(x-m)))**(a+1)
    return(s)

